CREATE DATABASE IF NOT EXISTS asset_db;
USE asset_db;

CREATE TABLE assets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    type VARCHAR(100),
    status VARCHAR(50)
);

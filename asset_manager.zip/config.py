# config.py
MYSQL_HOST = 'localhost'
MYSQL_USER = 'root'
MYSQL_PASSWORD = 'yourpassword'
MYSQL_DB = 'asset_db'

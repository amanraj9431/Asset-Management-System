from flask import Flask, render_template, request, redirect, url_for
import mysql.connector
from config import *

app = Flask(__name__)

def get_db():
    return mysql.connector.connect(
        host=MYSQL_HOST,
        user=MYSQL_USER,
        password=MYSQL_PASSWORD,
        database=MYSQL_DB
    )

@app.route('/')
def dashboard():
    db = get_db()
    cursor = db.cursor(dictionary=True)
    cursor.execute("SELECT * FROM assets")
    assets = cursor.fetchall()
    total = len(assets)
    active = len([a for a in assets if a['status'] == 'Active'])
    maintenance = len([a for a in assets if a['status'] == 'Maintenance'])
    db.close()
    return render_template('dashboard.html', assets=assets, total=total, active=active, maintenance=maintenance)

@app.route('/add', methods=['POST'])
def add_asset():
    name = request.form['name']
    type_ = request.form['type']
    status = request.form['status']
    db = get_db()
    cursor = db.cursor()
    cursor.execute("INSERT INTO assets (name, type, status) VALUES (%s, %s, %s)", (name, type_, status))
    db.commit()
    db.close()
    return redirect(url_for('dashboard'))

@app.route('/delete/<int:id>')
def delete_asset(id):
    db = get_db()
    cursor = db.cursor()
    cursor.execute("DELETE FROM assets WHERE id = %s", (id,))
    db.commit()
    db.close()
    return redirect(url_for('dashboard'))

if __name__ == '__main__':
    app.run(debug=True)
